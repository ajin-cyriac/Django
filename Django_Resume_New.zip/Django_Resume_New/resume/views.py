from django.shortcuts import render

def resume_view(request):
    resume = {
        'name': 'Ajin Cyriac',
        'age': 25,
        'gender': 'male',
        'email': 'ajincyriac852@gnail.com',
        'skills': [
            'Python',
            'Java',
            'HTML',
            'CSS',
            'Django',
            'MySQL'
        ],
        'education': {
            'Diploma': 'Computer Engineering 2022',
            'BTech': 'Computer Engineering 2026'
        }
    }

    return render(request, 'resume/resume.html', {
        'resume': resume
    })